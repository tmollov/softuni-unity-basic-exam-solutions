﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerShipScript : MonoBehaviour
{
    public static int Score;
    public GameObject RocketPrefab;
    public GameObject RocketLaunchPositionGO;

    public Slider scoreBar;

    float speed = 0.18f;
    float minX = -15f;
    float maxX = 15f;
    float minZ = -4.2f;
    float maxZ = 12f;
    float horizontalAxis;
    float verticalAxis;

    private void Start()
    {
        Application.targetFrameRate = 60;
    }

    void Update()
    {
        horizontalAxis = Input.GetAxis("Horizontal");
        verticalAxis = Input.GetAxis("Vertical");

        var position = transform.position;
        position += new Vector3(horizontalAxis * speed, 0f, verticalAxis * speed);
        position = new Vector3(
            Mathf.Clamp(position.x, minX, maxX), position.y,
            Mathf.Clamp(position.z, minZ, maxZ));
        transform.position = position;

        var targetAngle = horizontalAxis * 20;
        var progress = Mathf.Abs(horizontalAxis) / 1f;
        var yAngle = Mathf.LerpAngle(transform.rotation.eulerAngles.y, targetAngle, progress);
        transform.rotation = Quaternion.Euler(0f, yAngle, 0f);

        // Task 2
        if (Input.GetKeyDown(KeyCode.Mouse0))
            Fire();

        // Task 5
        RefreshScore();
    }

    private void Fire()
    {
        // Task 6
        var camera = Camera.main;
        var mousePos = Input.mousePosition;
        mousePos.z = camera.transform.position.z;
        var ray = camera.ScreenPointToRay(mousePos);

        if (Physics.Raycast(ray, out var hit))
        {
            if (hit.transform.CompareTag("Building"))
            {
                var move = hit.point;
                var launchPosition = RocketLaunchPositionGO.transform;
                var rocket = Instantiate(RocketPrefab, launchPosition.position, launchPosition.rotation);

                rocket.transform.LookAt(hit.transform);
            }
        }
    }

    public void RefreshScore()
    {
        scoreBar.value = Score;
    }
}